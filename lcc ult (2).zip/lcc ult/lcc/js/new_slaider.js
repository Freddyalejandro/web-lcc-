window.addEventListener('load',function(){
    console.log('el estado cambio');

    var imag = [];

    imag[0]= 'img/galeria1.img1.png';
    imag[1]= 'img/lasproyect2.jpg';
    imag[2]= 'img/lasproyect3.jpg';
    document.slaider.src = imag[0];
    

});